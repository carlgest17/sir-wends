﻿using System;
using System.Collections.Generic;

namespace sampleMVC.Entities
{
    public partial class Category
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
